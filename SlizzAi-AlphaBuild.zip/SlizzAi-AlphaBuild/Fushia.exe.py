import os
import platform
import numpy as np
import torch
from PIL import Image
import requests
import subprocess

# Slizzurp Imports
import slizzurp_utils
import slizzurp_config
import slizzurp_io
import Operator  # Importing Operator.py for generative processes
import OrchestrationSlizzurp  # Importing orchestration functionalities

# Check OS Compatibility
if platform.system() != "Windows":
    raise SystemExit("Error: Fushia.py is designed for Windows 11.")

# Windows-Specific Function: Dependency Installer
def install_dependencies():
    """Automatically install Python dependencies on Windows using PowerShell."""
    try:
        subprocess.run(["powershell", "pip install numpy torch pillow requests"], check=True)
    except subprocess.CalledProcessError:
        print("Failed to install dependencies. Run manually: pip install numpy torch pillow requests")

# Module: Novi (Logic Processing)
class Novi:
    def __init__(self, config):
        self.config = config
        self.parameters = self.load_parameters()

    def load_parameters(self):
        return slizzurp_config.load_config()

    def preprocess_data(self, raw_input):
        processed_data = {"dimensions": raw_input.get("size", (512, 512)),
                          "color_profile": raw_input.get("color", "RGB")}
        return processed_data

# Main Orchestration: Fushia.py
class Fushia:
    def __init__(self):
        self.novi = Novi(slizzurp_config)
        self.operator = Operator.Operator("models/operator_model.pt")  # Using Operator module
        self.orchestrator = OrchestrationSlizzurp.Orchestrator()  # Assuming orchestration functions

    def execute(self, raw_input):
        structured_data = self.novi.preprocess_data(raw_input)
        
        # Use Orchestrator to enhance workflow
        processed_data = self.orchestrator.refine_data(structured_data)
        
        final_image = self.operator.generate_image(processed_data)
        
        # Windows Path Handling
        output_path = os.path.join(os.getcwd(), "output", "fushia_result.png")
        slizzurp_io.save_image(final_image, output_path)

# Example Usage
if __name__ == "__main__":
    install_dependencies()
    raw_data = {"size": (768, 768), "color": "RGB"}
    fushia = Fushia()
    fushia.execute(raw_data)
    print("✔ Fushia.py executed successfully on Windows 11.")